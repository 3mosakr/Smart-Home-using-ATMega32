/*
 * main.c
 *
 *  Created on: Mar 18, 2024
 *      Author: sakr3
 */

/********************************************************************************/
/*								FILES INCLUSIONS								*/
/********************************************************************************/
/******************LIB*******************/
//#include <avr/io.h>
//#include <util/delay.h>
#include "LIB/BIT_MATH.h"
#include "LIB/STD_TYPES.h"
//#include <string.h>

/*****************MCAL*******************/
#include "MCAL/DIO/DIO_Interface.h"
//#include "MCAL/GIE/GIE_Interface.h"
//#include "MCAL/EXTI/EXTI_Interface.h"
#include "MCAL/ADC/ADC_Interface.h"
//#include "MCAL/TIMERS/TIMERS_Interface.h"
//#include "MCAL/USART/USART_Interface.h"
#include "MCAL/SPI/SPI_Interface.h"
//#include "MCAL/TWI/TWI_Interface.h"

/*****************HAL*******************/
//#include "HAL/LCD/LCD_Interface.h"
//#include "HAL/KPD/KPD_Interface.h"
//#include "HAL/DCMOTOR/DCMOTOR_Interface.h"
//#include "HAL/STEPPER/STEPPER_Interface.h"
#include "HAL/LM35/LM35_Interface.h"
//#include "HAL/EEPROM/EEPROM_Interface.h"

/********************************************************************************/

/*************GLOBAL MACROS*************/
//#define F_CPU 8000000UL
//#define PASSWORD "2024"

/***********Global Variables************/
#define	TEMP1_READ 	0x01
#define	TEMP2_READ 	0x02

u8 global_u8SPIReceive = 0;

/**************Handlers*****************/
/* Application Initialization Function */
void APP_INIT(void);


/********************************************************************************/
/*								ENTRY POINT <main>								*/
/********************************************************************************/


int main(void)
{
	APP_INIT();
	u8 Local_u8TempValue1 = 0, Local_u8TempValue2 = 0, Local_u8DummySend = 0xff, Local_u8DummyReceive = 0xff;

	while (1) {

		/* Receive the room selector */
		SPI_u8Tranceive(Local_u8DummySend, &global_u8SPIReceive);

		/* Send Data from SPI To control MCU */
		if(global_u8SPIReceive == TEMP1_READ){
			/* read temp 1 */
			Local_u8TempValue1 = LM35_u16GetTempReading(CHANNEL0);
			SPI_u8Tranceive(Local_u8TempValue1, &Local_u8DummyReceive);
		}else if(global_u8SPIReceive == TEMP2_READ) {
			/* read temp 2 */
			Local_u8TempValue2 = LM35_u16GetTempReading(CHANNEL1);
			SPI_u8Tranceive(Local_u8TempValue2, &Local_u8DummyReceive);
		}else{

		}
		global_u8SPIReceive = 0;

	}
	return 0;
}


void APP_INIT(){
	/* configure the temp sensors pins as input */
	DIO_u8SetPinDirection(DIO_PORTA, DIO_PIN0, DIO_PIN_INPUT);
	DIO_u8SetPinDirection(DIO_PORTA, DIO_PIN1, DIO_PIN_INPUT);

	/* initialize using devices */
	LM35_voidInit();

	/* SPI Configuration Init slave */
	DIO_u8SetPinDirection(DIO_PORTB, DIO_PIN4, DIO_PIN_INPUT);
	DIO_u8SetPinDirection(DIO_PORTB, DIO_PIN5, DIO_PIN_INPUT);
	DIO_u8SetPinDirection(DIO_PORTB, DIO_PIN6, DIO_PIN_OUTPUT);
	DIO_u8SetPinDirection(DIO_PORTB, DIO_PIN7, DIO_PIN_INPUT);

	SPI_VoidInit();


}
