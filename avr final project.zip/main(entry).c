/*
 * main.c
 *
 *  Created on: Mar 18, 2024
 *      Author: sakr3
 */

/********************************************************************************/
/*								FILES INCLUSIONS								*/
/********************************************************************************/
/******************LIB*******************/
//#include <avr/io.h>
#include <util/delay.h>
#include "LIB/BIT_MATH.h"
#include "LIB/STD_TYPES.h"
#include <string.h>

/*****************MCAL*******************/
#include "MCAL/DIO/DIO_Interface.h"
//#include "MCAL/GIE/GIE_Interface.h"
//#include "MCAL/EXTI/EXTI_Interface.h"
//#include "MCAL/ADC/ADC_Interface.h"
//#include "MCAL/TIMERS/TIMERS_Interface.h"
#include "MCAL/USART/USART_Interface.h"
//#include "MCAL/SPI/SPI_Interface.h"
#include "MCAL/TWI/TWI_Interface.h"

/*****************HAL*******************/
#include "HAL/LCD/LCD_Interface.h"
#include "HAL/KPD/KPD_Interface.h"
//#include "HAL/DCMOTOR/DCMOTOR_Interface.h"
//#include "HAL/STEPPER/STEPPER_Interface.h"
//#include "HAL/LM35/LM35_Interface.h"
#include "HAL/EEPROM/EEPROM_Interface.h"

/********************************************************************************/
/***********Global Variables************/
typedef enum {
	HOME_CLOSED = 'C',
	HOME_OPENED = 'O',
	HOME_START = 'S'
}home_state_t;

/*************GLOBAL MACROS*************/
//#define F_CPU 8000000UL
//#define PASSWORD "2024"

/***********Global Variables************/
u8 global_u8Password[5] = "\0";
u8 global_u8PasswordChecker[5] = "\0";
u8 global_u8GeneratePassFlag = 0;

u8 global_u8PasswordTrial = 3;



/**************Handlers*****************/
/* Application Initialization Function */
void APP_INIT(void);

void lcd_generrate_pass(void);
void lcd_enter_pass(void);


/********************************************************************************/
/*								ENTRY POINT <main>								*/
/********************************************************************************/


int main(void)
{
	APP_INIT();


	u8 Local_u8Password[5] = "\0";
	u8 Local_u8PasswordCount = 0;
	u8 Local_u8Pressed = NOTPRESSED;

	lcd_generrate_pass();

	while (1) {

		if(0 == global_u8GeneratePassFlag){

			Local_u8Pressed = KPD_u8GetPressed();
			if (Local_u8Pressed != NOTPRESSED) {
				if ('?' == Local_u8Pressed){
					LCD_voidClearScreen();

					LCD_voidSendString((u8*)"Password ");
					LCD_voidSetPosition(LCD_ROW1, LCD_COLUMN2);
					LCD_voidSendString((u8*)"Generated.");
					_delay_ms(500);

					/* Store password on EEPROM */
					// EEPROM_voidSendDataByte(0, 7);
					for(u8 i = 0; i < 5; ++i){
						EEPROM_voidSendDataByte(i, (global_u8Password[i]));
					}

					Local_u8PasswordCount = 0;
					global_u8GeneratePassFlag = 1;
					lcd_enter_pass();
				}else{
					global_u8Password[Local_u8PasswordCount++] = Local_u8Pressed;
					LCD_voidSendData(Local_u8Pressed);
					Local_u8Pressed = NOTPRESSED;
				}
			}else{/* NOTHING */}

		}else{
			Local_u8Pressed = KPD_u8GetPressed();
			if (Local_u8Pressed != NOTPRESSED) {

				if ('?' == Local_u8Pressed) {

					LCD_voidClearScreen();

					/* Read password from eeprom and compare with input password */
					for(u8 i = 4; i <= 0; ++i){
						global_u8Password[i] = (u8)(EEPROM_u8ReadDataByte(i));
						_delay_ms(10);
					}

					if(!strcmp(global_u8Password, Local_u8Password)){
						/* correct password */
						USART_u8SendData(HOME_OPENED);
						LCD_voidSendString((u8*)"Welcome Home.");
						global_u8PasswordTrial = 3;
						_delay_ms(1000);
					}else{
						/* not correct password */
						LCD_voidSendString((u8*)"Incorrect");
						LCD_voidSetPosition(LCD_ROW1, LCD_COLUMN2);
						LCD_voidSendString((u8*)"Password.");
						_delay_ms(500);

						global_u8PasswordTrial -= 1;
						LCD_voidClearScreen();
						if(global_u8PasswordTrial == 0){
							USART_u8SendData(HOME_CLOSED);
							LCD_voidSendString((u8*)"System Stop");
							LCD_voidSetPosition(LCD_ROW1, LCD_COLUMN1);
							LCD_voidSendString((u8*)"Thief detected.");

							break;
						}else{
							LCD_voidSendString((u8*)"You have ");
							LCD_voidSendNumber(global_u8PasswordTrial);
							LCD_voidSetPosition(LCD_ROW1, LCD_COLUMN1);
							LCD_voidSendString((u8*)"Password Trials.");
							_delay_ms(500);
						}

					}
					/* reset Local_u8Password */
					memset(Local_u8Password, '\0', 5);
					Local_u8PasswordCount = 0;
					lcd_enter_pass();
				} else {
					Local_u8Password[Local_u8PasswordCount++] = Local_u8Pressed;
					LCD_voidSendData('*');
					Local_u8Pressed = NOTPRESSED;
				}

			}else{/* NOTHING */}
		}
	}
	return 0;
}


void APP_INIT(){
	LCD_voidInit();
	KPD_Init();
	TWI_voidInitMaster(0);
	USART_voidInit();
	USART_u8SendData(HOME_START);

}

void lcd_generrate_pass(){
	LCD_voidClearScreen();
	LCD_voidSendString((u8*)"Generate ");
	LCD_voidSetPosition(LCD_ROW1, LCD_COLUMN1);
	LCD_voidSendString((u8*)"Password: ");
}

void lcd_enter_pass(){
	LCD_voidClearScreen();
	LCD_voidSendString((u8*)"Please Enter ");
	LCD_voidSetPosition(LCD_ROW1, LCD_COLUMN1);
	LCD_voidSendString((u8*)"Password: ");
}

