/*
 * main.c
 *
 *  Created on: Mar 18, 2024
 *      Author: sakr3
 */

/********************************************************************************/
/*								FILES INCLUSIONS								*/
/********************************************************************************/
/******************LIB*******************/
//#include <avr/io.h>
#include <util/delay.h>
#include "LIB/BIT_MATH.h"
#include "LIB/STD_TYPES.h"
//#include <string.h>

/*****************MCAL*******************/
#include "MCAL/DIO/DIO_Interface.h"
#include "MCAL/GIE/GIE_Interface.h"
#include "MCAL/EXTI/EXTI_Interface.h"
//#include "MCAL/ADC/ADC_Interface.h"
#include "MCAL/TIMERS/TIMERS_Interface.h"
#include "MCAL/USART/USART_Interface.h"
#include "MCAL/SPI/SPI_Interface.h"
//#include "MCAL/TWI/TWI_Interface.h"
//#include "MCAL/PORT/PORT_Interface.h"

/*****************HAL*******************/
#include "HAL/LCD/LCD_Interface.h"
//#include "HAL/KPD/KPD_Interface.h"
//#include "HAL/DCMOTOR/DCMOTOR_Interface.h"
//#include "HAL/STEPPER/STEPPER_Interface.h"
//#include "HAL/LM35/LM35_Interface.h"
//#include "HAL/EEPROM/EEPROM_Interface.h"

/********************************************************************************/

/*************GLOBAL MACROS*************/
//#define F_CPU 8000000UL
//#define PASSWORD "2024"

/***********Global Variables************/
enum {
	HOME_CLOSED = 'C',
	HOME_OPENED = 'O',
	HOME_START = 'S'
};

#define	TEMP1_READ 	0x01
#define	TEMP2_READ 	0x02


u8 global_u8UARTReciveControlKey = HOME_START;
u8 global_u8SPITransmet = 0, global_u8SPIReceive = 0;

/**************Handlers*****************/
/* Application Initialization Function */
void APP_INIT(void);
void room1_fan_on(void);
void room2_fan_on(void);

/********************************************************************************/
/*								ENTRY POINT <main>								*/
/********************************************************************************/


int main(void)
{
	APP_INIT();

	while (1) {
		USART_u8RecevieData(&global_u8UARTReciveControlKey);

		if(global_u8UARTReciveControlKey == HOME_OPENED) {
			SPI_VoidInit();

			TIMER0_voidInit();
			TIMER2_voidInit();
			/* configure FAN1, FAN2 (OCs) pins as output */
			DIO_u8SetPinDirection(DIO_PORTB, DIO_PIN3, DIO_PIN_OUTPUT);
			DIO_u8SetPinDirection(DIO_PORTD, DIO_PIN7, DIO_PIN_OUTPUT);

			/* enable external interrupt */
			EXTI_voidInit();
			/* set ISR for EXT_INT0, EXT_INT1 */
			EXTI_u8Int0SetCallBack(room1_fan_on);
			EXTI_u8Int1SetCallBack(room2_fan_on);


			global_u8UARTReciveControlKey = HOME_START;
		}
		else if(global_u8UARTReciveControlKey == HOME_CLOSED) {
			/* home is closed there is a thief  */
			/* blinking leds  each 0.5 sec for 20 sec */
//			DIO_u8SetPortValue(DIO_PORTA, DIO_PORT_HIGH);
			DIO_u8SetPinValue(DIO_PORTA, DIO_PIN0, DIO_PIN_HIGH);

		}else{
			/* NOTHING */

		}
	}
	return 0;
}


void APP_INIT(){

	DIO_u8SetPinDirection(DIO_PORTA, DIO_PIN0, DIO_PIN_OUTPUT);
	DIO_u8SetPinValue(DIO_PORTA, DIO_PIN0, DIO_PIN_LOW);

	/* initialize using drivers */
	USART_voidInit();

	/* configure External interrupt (EXTI0, EXTI1) pins (ROOM 1, 2) */
	DIO_u8SetPinDirection(DIO_PORTB, DIO_PIN2, DIO_PIN_INPUT);
	DIO_u8SetPinDirection(DIO_PORTD, DIO_PIN3, DIO_PIN_INPUT);

	/* SPI Configuration Init Master */
	DIO_u8SetPinDirection(DIO_PORTB, DIO_PIN4, DIO_PIN_OUTPUT);
	DIO_u8SetPinDirection(DIO_PORTB, DIO_PIN5, DIO_PIN_OUTPUT);
	DIO_u8SetPinDirection(DIO_PORTB, DIO_PIN6, DIO_PIN_INPUT);
	DIO_u8SetPinDirection(DIO_PORTB, DIO_PIN7, DIO_PIN_OUTPUT);

	DIO_u8SetPinValue(DIO_PORTB, DIO_PIN4, DIO_PIN_LOW);
	DIO_u8SetPinValue(DIO_PORTB, DIO_PIN5, DIO_PIN_LOW);
	DIO_u8SetPinValue(DIO_PORTB, DIO_PIN7, DIO_PIN_LOW);



	/* enable global interrupt */
	GIE_voidEnable();


	LCD_voidInit();


}

void room1_fan_on(void){
	SPI_u8Tranceive(TEMP1_READ, &global_u8SPIReceive);

	LCD_voidClearScreen();
	LCD_voidSendString((u8*)"Temp 1 = ");
	LCD_voidSetPosition(LCD_ROW0, LCD_COLUMN10);
	LCD_voidSendNumber(global_u8SPIReceive);

	if(global_u8SPIReceive < 14){
		/* fan off */
		/*change ctc val of pwm */
		TIMER0_voidSetCTC(0);

	}else if((global_u8SPIReceive >= 14) && (global_u8SPIReceive < 20)){
		/* fan speed low */
		TIMER0_voidSetCTC(64);

	}else if((global_u8SPIReceive >= 20) && (global_u8SPIReceive < 30)){
		/* fan speed mid */
		TIMER0_voidSetCTC(128);

	}else if(global_u8SPIReceive >= 30){
		/* fan speed high */
		TIMER0_voidSetCTC(255);
	}
}

void room2_fan_on(void){
	SPI_u8Tranceive(TEMP2_READ, &global_u8SPIReceive);

	LCD_voidClearScreen();
	LCD_voidSendString((u8*)"Temp 2 = ");
	LCD_voidSetPosition(LCD_ROW0, LCD_COLUMN10);
	LCD_voidSendNumber(global_u8SPIReceive);

	if(global_u8SPIReceive < 14){
		/* fan off */
		/*change ctc val of pwm */
		TIMER2_voidSetCTC(0);

	}else if((global_u8SPIReceive >= 14)&&(global_u8SPIReceive < 20)){
		/* fan speed low */
		TIMER2_voidSetCTC(64);

	}else if((global_u8SPIReceive >= 20)&&(global_u8SPIReceive < 30)){
		/* fan speed mid */
		TIMER2_voidSetCTC(128);

	}else if(global_u8SPIReceive >= 30){
		/* fan speed high */
		TIMER2_voidSetCTC(255);
	}
}
